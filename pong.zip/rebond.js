// Fonction pour gérer les cookies
function setCookie(nom, valeur, jours) {
  var d = new Date();
  d.setTime(d.getTime() + jours * 24 * 60 * 60 * 1000);
  var expires = "expires=" + d.toUTCString();
  document.cookie = nom + "=" + valeur + ";" + expires + ";path=/";
}

function getCookie(nom) {
  var nomCookie = nom + "=";
  var tableauCookies = document.cookie.split(";");
  for (var i = 0; i < tableauCookies.length; i++) {
    var c = tableauCookies[i].trim();
    if (c.indexOf(nomCookie) == 0) {
      return c.substring(nomCookie.length, c.length);
    }
  }
  return "";
}

// Enregistrement des scores dans les cookies
function enregistrerScoresDansCookies(scores) {
  setCookie("meilleursScores", JSON.stringify(scores), 365);
}

// Lecture des scores depuis les cookies
function chargerScoresDepuisCookies() {
  var scoresCookie = getCookie("meilleursScores");
  if (scoresCookie) {
    return JSON.parse(scoresCookie);
  }
  return [];
}

window.onload = function () {
  var canvas = document.getElementById("monCanvas");
  var contexte = canvas.getContext("2d");

  var rayonBalle = 6;
  var x = canvas.width / 2;
  var y = canvas.height / 2;
  var dx = 2;
  var dy = 2;

  var positionRaquetteX = canvas.width / 2 - 25;
  var positionRaquetteY = canvas.height - 20;
  var largeurRaquette = 50;
  var hauteurRaquette = 10;

  var score = 0;
  var meilleurScore = 0;
  var meilleursScores = chargerScoresDepuisCookies(); // Charge les scores depuis les cookies
  var pseudoActuel = "";

  document.getElementById("difficulte").addEventListener("change", function () {
    const difficulteSelectionnee = this.value;

    if (difficulteSelectionnee === "facile") {
      dx = 1;
      dy = 1;
      largeurRaquette = 80;
      document.getElementById("modeExpert").style.display = "none";
    } else if (difficulteSelectionnee === "moyen") {
      dx = 2;
      dy = 2;
      largeurRaquette = 50;
      document.getElementById("modeExpert").style.display = "none";
    } else if (difficulteSelectionnee === "difficile") {
      dx = 3;
      dy = 3;
      largeurRaquette = 40;
      document.getElementById("modeExpert").style.display = "none";
    } else if (difficulteSelectionnee === "expert") {
      document.getElementById("modeExpert").style.display = "block";
      dx = parseInt(document.getElementById("vitesseBalle").value);
      dy = dx;
      largeurRaquette = parseInt(
        document.getElementById("tailleRaquette").value
      );
    }
  });

  // Mettre à jour les réglages du mode expert
  document
    .getElementById("vitesseBalle")
    .addEventListener("input", function () {
      if (document.getElementById("difficulte").value === "expert") {
        dx = parseInt(this.value);
        dy = dx;
      }
    });

  document
    .getElementById("tailleRaquette")
    .addEventListener("input", function () {
      if (document.getElementById("difficulte").value === "expert") {
        largeurRaquette = parseInt(this.value);
      }
    });

  function dessinerBalle() {
    contexte.beginPath();
    contexte.arc(x, y, rayonBalle, 0, Math.PI * 2);
    contexte.fillStyle = "#5865F2";
    contexte.fill();
    contexte.closePath();
  }

  function lectureClavier(evt) {
    switch (evt.keyCode) {
      case 37: // Flèche gauche
        if (positionRaquetteX > 0) {
          positionRaquetteX -= 20;
        }
        break;
      case 39: // Flèche droite
        if (positionRaquetteX < canvas.width - largeurRaquette) {
          positionRaquetteX += 20;
        }
        break;
    }
  }

  function dessinerRaquette() {
    contexte.beginPath();
    contexte.fillStyle = "#5865F2";
    contexte.fillRect(
      positionRaquetteX,
      positionRaquetteY,
      largeurRaquette,
      hauteurRaquette
    );
    contexte.closePath();
  }

  window.addEventListener("keydown", lectureClavier, true);

  function dessiner() {
    contexte.clearRect(0, 0, canvas.width, canvas.height);

    contexte.fillStyle = " #000000";
    contexte.fillRect(0, 0, canvas.width, canvas.height);

    dessinerRaquette();
    dessinerBalle();

    if (x + dx > canvas.width - rayonBalle || x + dx < rayonBalle) {
      dx = -dx; // Inverse la direction horizontale
      canvas.style.boxShadow = "0px 0px 30px green"; // Ajoute un effet visuel (optionnel)
      console.log("haut");
    }

    if (y + dy < rayonBalle) {
      dy = -dy; // Inverse la direction verticale
    }
    if (
      y + rayonBalle >= positionRaquetteY && // Vérifie si la balle est à la hauteur de la raquette (collision verticale)
      x + rayonBalle > positionRaquetteX && // Vérifie si la balle touche le bord gauche de la raquette
      x - rayonBalle < positionRaquetteX + largeurRaquette // Vérifie si la balle touche le bord droit de la raquette
    ) {
      var audio = new Audio("beep.mp3"); // Son de rebond
      score++; // Incrémentation du score
      meilleurScore = Math.max(score, meilleurScore); // Mise à jour du meilleur score

      // Mise à jour de l'affichage du score
      document.getElementById("affichageScore").innerHTML =
        "Score :<span style='color:#57F287;'>" +
        score +
        "</span> | Meilleur score : " +
        meilleurScore;

      dy = -dy; // Inverse la direction verticale
    }

    if (y + dy > canvas.height - rayonBalle) {
      var audio = new Audio("perdu.mp3");
      audio.play(); // Joue le son de défaite
      canvas.style.boxShadow = "0px 0px 30px #ff0000"; // Ajoute un effet visuel

      ajouterScore(pseudoActuel, score); // Sauvegarde le score
      score = 0; // Réinitialise le score

      // Mise à jour de l'affichage pour indiquer la défaite
      document.getElementById("affichageScore").innerHTML =
        "<span style='color:red;'> Perdu</span> | Meilleur score : " +
        meilleurScore;

      // Réinitialisation de la position et de la direction de la balle
      x = canvas.width / 2;
      y = Math.floor(Math.random() * 100) + 10; // Nouvelle position aléatoire verticale
      dy = -dy; // Inverse la direction verticale
    }

    x += dx;
    y += dy;
  }

  // Ajout du score et mise à jour des cookies
  function ajouterScore(pseudo, score) {
    meilleursScores.push({ pseudo: pseudo, score: score });
    meilleursScores.sort((a, b) => b.score - a.score); // Tri par ordre décroissant

    // Limite à 5 meilleurs scores
    if (meilleursScores.length > 5) {
      meilleursScores.pop();
    }

    enregistrerScoresDansCookies(meilleursScores); // Enregistre les scores dans les cookies
    mettreAJourTableScores();
  }

  // Mise à jour de la table des scores
  function mettreAJourTableScores() {
    var listeScores = document.getElementById("listeScores");
    listeScores.innerHTML = ""; // Réinitialise la table
    meilleursScores.forEach(function (entree) {
      var ligne = document.createElement("tr");
      var cellulePseudo = document.createElement("td");
      var celluleScore = document.createElement("td");
      cellulePseudo.textContent = entree.pseudo;
      celluleScore.textContent = entree.score;
      ligne.appendChild(cellulePseudo);
      ligne.appendChild(celluleScore);
      listeScores.appendChild(ligne);
    });
  }

  // Démarre le jeu après la soumission du pseudo
  document
    .getElementById("formPseudo")
    .addEventListener("submit", function (e) {
      e.preventDefault();
      pseudoActuel = document.getElementById("pseudo").value; // Récupère le pseudo
      document.getElementById("pseudo").disabled = true; // Désactive l'entrée du pseudo après démarrage
      setInterval(dessiner, 1000 / 60); // Lance le jeu à 60 FPS
    });

  // Charge les scores au chargement de la page
  mettreAJourTableScores();
};
