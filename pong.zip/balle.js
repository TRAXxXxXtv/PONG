window.onload = function () {
  var canvas = document.getElementById("mon_canvas");
  if (!canvas) {
    alert("Impossible de récupérer le canvas");
    return;
  }

  var context = canvas.getContext("2d");
  if (!context) {
    alert("Impossible de récupérer le context du canvas");
    return;
  }
  var expr = 1;
  function animate() {
    context.fillStyle = "rgb(199, 208, 204)";
    context.fillRect(0, 0, 300, 300); // Clear canvas
    context.save();
    context.beginPath();
    context.fillStyle = "rgb(96, 80, 220)";

    if (expr < 5) {
      expr++;

      switch (expr) {
        case 1:
          context.translate(10, 10);
          console.log("1");

          break;
        case 2:
          context.translate(290, 10);
          console.log("2");
          break;
        case 3:
          context.translate(290, 290);
          console.log("3");
          // Expected output: "Mangoes and papayas are $2.79 a pound."
          break;
        case 4:
          context.translate(10, 290);
          console.log("4");
          break;
        default:
          context.translate(10, 10);
          console.log("default");
      }
    } else {
      expr = 1;
    }
    context.arc(0, 0, 10, 0, Math.PI * 2); // Draw circle
    context.fill();
    context.closePath();
    context.restore();
  }

  // Animate every second
  var myInterval = setInterval(animate, 1000 / 1);
};
