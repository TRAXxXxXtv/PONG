window.onload = function () {
  var canvas = document.getElementById("mon_canvas");
  if (!canvas) {
    alert("Impossible de récupérer le canvas");
    return;
  }

  var context = canvas.getContext("2d");
  if (!context) {
    alert("Impossible de récupérer le context du canvas");
    return;
  }

  var myInterval = setInterval(animate, 1000 / 30);

  function animate() {
    // faire ici la partie graphique
    //Rectangle extérieur

    //arcs de cercle - Etoile
    context.beginPath();
    context.fillStyle = "rgb(128,128,255)";
    context.arc(250, 250, 100, Math.PI, (3 * Math.PI) / 2); //point2-3
    context.arc(50, 250, 100, (3 * Math.PI) / 2, 2 * Math.PI); //point3-4
    context.arc(50, 50, 100, 2 * Math.PI, Math.PI / 2); //point4-1
    context.arc(250, 50, 100, Math.PI / 2, Math.PI); //point1-2
    context.stroke();
    context.closePath();
    context.fill();
  }
};
